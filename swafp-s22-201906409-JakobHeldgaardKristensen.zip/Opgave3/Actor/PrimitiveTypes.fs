﻿module Opgave3.Actor.PrimitiveTypes

type AccountId = string
type ProjectId = string
type TodoId = string
type TodoContent = string
