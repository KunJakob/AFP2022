﻿module Opgave_4.Task

open Opgave_4.Employee

type Task = { id: string; assignee: Employee }
