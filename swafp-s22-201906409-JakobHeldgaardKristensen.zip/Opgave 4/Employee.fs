﻿module Opgave_4.Employee

type Employee = { name: string }
