module Tests

open Xunit

[<Fact>]
let ``My test`` () = Assert.True(true)
